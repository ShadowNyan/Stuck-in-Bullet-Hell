#include "GameObject.h"

void GameObject::initImg(char* filepath)
{
	sprite.load(filepath);
}

class Button :
	public GameObject
{
};
