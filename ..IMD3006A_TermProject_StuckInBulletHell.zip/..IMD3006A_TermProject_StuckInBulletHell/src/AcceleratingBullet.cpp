#include "AcceleratingBullet.h"

AcceleratingBullet::AcceleratingBullet(Player* PlayerToTarget, int startX, int startY)
{
	target = PlayerToTarget;
	xPos = startX;
	yPos = startY;
	damage = 15;
	speed = 1;

	direction.x = target->xPos - xPos; //////
	direction.y = target->yPos - yPos; //////
	direction = direction.getNormalized();

	sprite.load("AcceleratingBullet.png"); /////// REPLACE WITH ACTUAL IMAGE LATER

}
void AcceleratingBullet::move()
{
	speed += 0.1;
	xPos += direction.x * speed;
	yPos += direction.y * speed;

	currDirection = direction;
}
