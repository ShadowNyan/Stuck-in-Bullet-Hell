#pragma once
#include "GameObject.h"
#include "Player.h"
class Bullet :
    public GameObject
{
public:

    float speed = 1; ////
    int damage = 1;
    bool isActive = true;
    Player* target;
    ofVec2f currDirection;

    Bullet* next;
    Bullet* previous;

    virtual void move() {};
    bool hasHit();

};

