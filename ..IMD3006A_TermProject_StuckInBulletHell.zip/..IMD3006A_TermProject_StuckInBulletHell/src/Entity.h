#pragma once
#include "GameObject.h"
#include "ofMain.h"
class Entity :
    public GameObject
{
public:
    int currentHealth = 100;
    int maxHealth = 100;
    ofVec2f direction;
    int speed = 5;

    virtual enum state
    {
        /*IDLE = 0,
        ATTACKING = 1,
        MOVING = 2,
        DEAD = 3*/
        ATTACKING = 0,
        MOVING = 1,
        DEAD = 2,
        IDLE = 3,

    };
    int currentState;
    

    virtual void move();
    virtual void attack();
    void takeDamage(int damageAmnt);
    virtual void ifDead();

};

