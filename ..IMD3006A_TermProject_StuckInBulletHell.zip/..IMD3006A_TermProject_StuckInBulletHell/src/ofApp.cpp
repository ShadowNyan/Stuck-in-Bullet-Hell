#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	//ofSetRectMode(OF_RECTMODE_CENTER);

	ofSetWindowShape(1920, 1080);
	ofSetFrameRate(120);

	ui.initButtons();
	

	//////TEMP
	player.xPos = ofGetWindowWidth() /2;
	player.yPos = ofGetWindowHeight() /4 * 3;
	player.direction.x = 0;
	player.direction.y = 0;

}

//--------------------------------------------------------------
void ofApp::update(){
	if (gameState.currScreen == gameState.PLAY)
	{
		////////////////// UPDATE GAME VALUES HERE (NOT PAUSED) //////////////////////////////////////////////////////////////////////////////////////////

		/////FOR BOSS//////////////////////////////////////////////////////////////////////////

		/////// IF STATE IS MOVING
		int wallDistanceBuffer = 200;
		if (boss.currentState == boss.MOVING)
		{
			boss.move();
		}
		else if (boss.currentState == boss.KNOCKEBACK)
		{
			bool finishedKnockback = boss.damagedKnockback(player.xPos, player.yPos);
			if (finishedKnockback == true)
			{
				//if the boss is knocked near teh wall, move away from the wall
				if (wallDistanceBuffer > boss.xPos || ofGetWindowWidth() - wallDistanceBuffer < boss.xPos || wallDistanceBuffer > boss.yPos || ofGetWindowHeight() - wallDistanceBuffer < boss.yPos)
				{
					boss.switchState(boss.MOVING);
				}
				else
				{
					boss.switchState(boss.IDLE);
				}
			}
		}
		/////// IF STATE IS ATTACKING
		else if (boss.currentState == boss.ATTACKING)
		{
			///////// MOVE ALL THIS TO BOSS.ATTACK()?????
			static int timer = 0;
			if (timer == 0)
			{
				////ATTACK HERE

				//add to the pool of possible bullet types as the phases progress
				int bulletTypeToAdd = ofRandom(0, boss.currentPhase+1); ///random number from 0 to 4 depending on boss phase
				switch (bulletTypeToAdd)
				{
				case 0: //NORMAL
					bulletList.addBullet(&player, boss.xPos, boss.yPos, bulletList.NORMAL);
					break;
				case 1: //HOMING
					bulletList.addBullet(&player, boss.xPos, boss.yPos, bulletList.HOMING);
					break;
				case 2: //ACCELERATING
					bulletList.addBullet(&player, boss.xPos, boss.yPos, bulletList.ACCELERATING);
					break;
				case 3: //CURVE
					bulletList.addBullet(&player, boss.xPos, boss.yPos, bulletList.CURVING);
					break;
				}

				///////////  ATTACK AGAIN ?
				float attackAgainChance = ofRandom(100);
				if (attackAgainChance <= 90)
				{
					boss.switchState(boss.ATTACKING);
				}
				else
				{
					boss.switchState(boss.IDLE);
				}
			}

			timer++;
			if (timer >= boss.fireRate) //originally permanantly set to 20, currently changes when boss switches phases
			{
				timer = 0;
			}

		}
		/////// IF STATE IS DEAD
		else if (boss.currentState == boss.DEAD)
		{
			boss.nextPhase();

			if (boss.currentPhase == boss.SURVIVE)
			{
				timer.startTimer();
			}

		}
		/////// IF STATE IS IDLE
		else if (boss.currentState == boss.IDLE || boss.currentState > 4)
		{
			int newState = (int)ofRandom(0, 2); //generates number from 0 to 1 (ATTACKING OR MOVING)
			boss.switchState(newState);
		}
		/////////

		///// FOR PLAYER//////////////////////////////////////////////////////////////////////////////

		/// update the cooldown for the player's dash if applicable
		if (player.onCooldown == true)
		{
			player.cooldown++;

			if (player.cooldown >= player.cooldownMax)
			{
				player.cooldown = 0;
				player.onCooldown = false;
			}
		}

		/////// IF STATE IS MOVING
		if (player.currentState == player.MOVING || player.currentState == player.IDLE)
		{
			player.move();

			if (player.direction.x == 0 && player.direction.y == 0)
			{
				player.currentState = player.IDLE;
			}
			else
			{
				player.currentState = player.MOVING;
			}

		}
		/////// IF STATE IS ATTACKING
		if (player.currentState == player.ATTACKING)
		{

			bool finishedKnockback = player.dash(&boss);

			if (finishedKnockback == true)			  //
			{
				player.onCooldown = true;
				player.currentState = player.IDLE;	  //
			}

		}
		/////// IF STATE IS DEAD
		if (player.currentState == player.DEAD)
		{
			gameState.currScreen = gameState.GAMEOVER;
		}


		///// FOR PICKUPS //////////////////////////////////////////////////////////////////////////////

		////// randomly create a new pickup
		float spawnPickup = ofRandom(100);
		if (spawnPickup <= 0.05)
		{
			if (numPickups < MAX_PICKUPS)
			{
				pickups[numPickups] = new HealthPickup();
				numPickups++;
			}
		}

		////// update the 'state' of all pickups
		for (int i = 0; i < MAX_PICKUPS; i++)
		{
			if (pickups[i] != NULL)
			{
				bool isPickedUp = pickups[i]->isPickedUp(&player, &numPickups);
				if (isPickedUp == true)
				{
					delete pickups[i];
					pickups[i] = NULL;
				}
			}
		}

		///// FOR BULLETS //////////////////////////////////////////////////////////////////////////////

		bulletList.updateBullets(&player);


		///// FOR TIMER //////////////////////////////////////////////////////////////////////////////
		timer.updateTimer();


	}
	else
	{
		
	}
}

//--------------------------------------------------------------
void ofApp::draw(){
	
	////////////////  DRAW MAIN GAME SCREEN ////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (gameState.currScreen == gameState.PLAY)
	{
		//////// DRAW BACKGROUND //////////////////////////////////////////////////////////////////////////////////////////////////////////////

		ui.drawGameBG();

		//////// DRAW HEALTH BARS //////////////////////////////////////////////////////////////////////////////////////////////////////////////

		// draw health bar for the boss //////////////
		if (boss.currentPhase != boss.SURVIVE)
		{
			ofSetRectMode(OF_RECTMODE_CENTER);
			ofSetColor(ofColor::red);

			ofRectangle bossHealthBar;
			bossHealthBar.height = 50;
			bossHealthBar.width = boss.currentHealth * 2;
			bossHealthBar.x = ofGetWindowWidth() / 2;
			bossHealthBar.y = 0;
			ofDrawRectangle(bossHealthBar);

			ofSetColor(ofColor::white);
			ofSetRectMode(OF_RECTMODE_CORNER);
		}

		//draw health bar for the player ////////////
		ofSetRectMode(OF_RECTMODE_CENTER);
		ofSetColor(ofColor::aqua);

		ofRectangle playerHealthBar;
		playerHealthBar.height = 50;
		playerHealthBar.width = player.currentHealth * 5;
		playerHealthBar.x = ofGetWindowWidth() / 2;
		playerHealthBar.y = ofGetWindowHeight();
		ofDrawRectangle(playerHealthBar);

		ofSetColor(ofColor::white);
		ofSetRectMode(OF_RECTMODE_CORNER);

		//////// DRAW TIMER //////////////////////////////////////////////////////////////////////////////////////////////////////////////
		if (boss.currentPhase == boss.SURVIVE)
		{
			timer.drawTimer();
		}
		

		////// DRAW PICKUPS //////////////////////////////////////////////////////////////////////////////////////////////////////////////

		for (int i = 0; i < MAX_PICKUPS; i++)
		{
			if (pickups[i] != NULL && numPickups > 0)
			{
				//ofSetColor(ofColor::cyan);
				//ofDrawCircle(pickups[i]->xPos, pickups[i]->yPos, 20);
				//ofSetColor(ofColor::white);

				ofPushMatrix();
					float drawX = pickups[i]->xPos - pickups[i]->sprite.getWidth() / 2;
					float drawY = pickups[i]->yPos - pickups[i]->sprite.getHeight() / 2;
					ofTranslate(drawX, drawY);
					render.Draw(pickups[i]);
				ofPopMatrix();

				//render.Draw(pickups[i]);
			}
		}

		//////// DRAW BULLETS //////////////////////////////////////////////////////////////////////////////////////////////////////////////

		bool keepLooping = true;
		Bullet* currBullet = bulletList.firstBullet;
		while (keepLooping)
		{
			if (currBullet != NULL)
			{
				/////TEMP
				//ofSetColor(ofColor::red);
				//ofDrawCircle(currBullet->xPos, currBullet->yPos, 15);
				//ofSetColor(ofColor::white);

				///// DRAWING ALGO FOR BULLETS
				ofPushMatrix();
					// translate sprite to current pos
					ofTranslate(currBullet->xPos, currBullet->yPos);
					
					//get zero angle vector (straiht horizontal line)
					ofVec2f zeroAngleVector;
					zeroAngleVector.x = 1;
					zeroAngleVector.y = 0;
					//find angle between zero angle and direction, then rotate sprite based on obj direction			currBullet->currDirection.angle(zeroAngleVector);
					ofRotate( - currBullet->currDirection.angle(zeroAngleVector));

					//translate so that the sprite center coressponds to the position
					float drawX = - currBullet->sprite.getWidth() / 2;
					float drawY = - currBullet->sprite.getHeight() / 2;
					ofTranslate(drawX, drawY);

					//call render object and draw the sprite
					render.Draw(currBullet);
					
				ofPopMatrix();
				//render.Draw(currBullet);

			}

			if (currBullet == bulletList.lastBullet)
			{
				keepLooping = false;
			}
			else
			{
				currBullet = currBullet->next;
			}
		}


		////////

		////// DRAW BOSS //////////////////////////////////////////////////////////////////////////////////////////////////////////////
		switch (boss.currentPhase)
		{
		case 0:
			ofSetColor(ofColor::black);
			break;
		case 1:
			ofSetColor(ofColor::red);
			break;
		case 2:
			ofSetColor(ofColor::purple);
			break;
		case 3:
			ofSetColor(ofColor::mediumPurple);
			break;
		}
		ofDrawCircle(boss.xPos, boss.yPos, 50);
		ofSetColor(ofColor::white);


		ofPushMatrix();
			float drawX = boss.xPos - boss.sprite.getWidth() / 2;
			float drawY = boss.yPos - boss.sprite.getHeight() / 2;
			ofTranslate(drawX, drawY);
			render.Draw(&boss);
		ofPopMatrix();
		//render.Draw(&boss);

		//////////


		//////// DRAW PLAYER //////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//ofSetColor(ofColor::white);
		//ofDrawCircle(player.xPos, player.yPos, 20);
		//ofSetColor(ofColor::white);

		/*ofPushMatrix();
			drawX = player.xPos - player.sprite.getWidth() / 2;
			drawY = player.yPos - player.sprite.getHeight() / 2;
			ofTranslate(drawX, drawY);
			render.Draw(&player);
		ofPopMatrix();*/

		ofPushMatrix();
		// translate sprite to current pos
		ofTranslate(player.xPos, player.yPos);

		//get zero angle vector (straiht horizontal line)
		ofVec2f zeroAngleVector;
		zeroAngleVector.x = 1;
		zeroAngleVector.y = 0;
		//find angle between zero angle and direction, then rotate sprite based on obj direction			currBullet->currDirection.angle(zeroAngleVector);

		if (player.currentState == player.MOVING || player.currentState == player.ATTACKING)
		{
			ofRotate(-player.direction.angle(zeroAngleVector) + 90);
		}
		else if (player.currentState == player.IDLE)
		{
			ofRotate(-player.direction.angle(zeroAngleVector));
		}

		//translate so that the sprite center coressponds to the position
		float drawPlayerX = -player.sprite.getWidth() / 2;
		float drawPlayerY = -player.sprite.getHeight() / 2;
		ofTranslate(drawPlayerX, drawPlayerY);

		//call render object and draw the sprite
		render.Draw(&player);

		ofPopMatrix();
		//render.Draw(&player);

		////////

	}
	////////////////  DRAW MENU SCREENS ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	else if (gameState.currScreen == gameState.START)
	{
		ui.drawStartUI();

		//ofSetColor(ofColor::white); ////TEST
		//ofDrawCircle(0, 0, 50);

	}
	else if (gameState.currScreen == gameState.GAMEOVER)
	{
		ui.drawGameOverUI();

		///// draw final timer score if final phase reached
		ofPushMatrix();

		if (boss.currentPhase == boss.SURVIVE)
		{
			ofTranslate(ofGetWindowWidth() / 2 - 100, ofGetWindowHeight() / 4);
			timer.drawTimer();
		}

		ofPopMatrix;
		

		//ofSetColor(ofColor::red); ////TEST
		//ofDrawCircle(0, 0, 50);

	}
	else if (gameState.currScreen == gameState.PAUSE)
	{
		ui.drawPauseUI();

		//ofSetColor(ofColor::yellow); ////TEST
		//ofDrawCircle(0, 0, 50);

	}

	ofSetColor(ofColor::white); ///////// RESET OF SET COLOR
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	if (key == OF_KEY_BACKSPACE)
	{
		if (gameState.currScreen == gameState.PLAY)
		{
			gameState.currScreen = gameState.PAUSE;
		}
		else if (gameState.currScreen == gameState.PAUSE)
		{
			gameState.currScreen = gameState.PLAY;
		}
	}


	////////// WASD PLAYER MOVEMENT
	// *Note: can't move if keyboard has caps on
	if (key == (int)'w')
	{
		player.currentState = player.MOVING;
		player.inputStoreY[0] = -1;

	}
	if (key == (int)'a')
	{
		player.currentState = player.MOVING;
		player.inputStoreX[0] = -1;

	}
	if (key == (int)'s')
	{
		player.currentState = player.MOVING;
		player.inputStoreY[1] = 1;
	}
	if (key == (int)'d')
	{
		player.currentState = player.MOVING;
		player.inputStoreX[1] = 1;

	}

	if (key == 32)
	{
		///// TEMP FOR BOSS (KNOCKBACK)
		//boss.needSetTarget = true;
		//cout << "setToKnock" << endl;
		//boss.currentState = boss.KNOCKEBACK;
		////////
		if (player.onCooldown == false)
		{
			player.currentState = player.ATTACKING;
		}

	}

	if (key == OF_KEY_CONTROL)
	{
		//player.takeDamage(10);
		//bulletList.removeBullet(bulletList.firstBullet);
		boss.nextPhase();

		if (boss.currentPhase == boss.SURVIVE)
		{
			timer.startTimer();
		}


	}

	//to return back to menu
	if (key == OF_KEY_ALT) 
	{
		//CANNOT make this the escape key
		//escape key immediately closes the game
		gameState.currScreen = gameState.START;
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

	////////// WASD PLAYER MOVEMENT
	if (key == (int)'w')
	{
		player.inputStoreY[0] = 0;

	}
	if (key == (int)'a')
	{
		player.inputStoreX[0] = 0;
		//cout << "A released" << endl;
	}
	if (key == (int)'s')
	{
		player.inputStoreY[1] = 0;
	}
	if (key == (int)'d')
	{
		player.inputStoreX[1] = 0;
		//cout << "D released" << endl;
	}

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {




	////////////////////////////// IF UI BUTTON IS CLICKED //////////////////////////
	if (button == OF_MOUSE_BUTTON_LEFT && gameState.currScreen != gameState.PLAY)
	{	
		
		ofRectangle* buttonClicked = ui.checkIfClicked(x, y);
		if (buttonClicked == &ui.UIbutton[ui.PLAYBUTTON]->button)
		{
			gameState.switchState(gameState.PLAY);
		}
		if (buttonClicked == &ui.UIbutton[ui.QUITBUTTON]->button)
		{
			OF_EXIT_APP(0)
		}
		if (buttonClicked == &ui.UIbutton[ui.MAINMENU]->button)
		{
			////reset all values//////////////////////////////
			//reset player values
			player.xPos = ofGetWindowWidth() / 2;
			player.yPos = ofGetWindowHeight() / 4 * 3;
			player.direction.x = 0;
			player.direction.y = 0;
			player.currentHealth = player.maxHealth;
			player.currentState = player.IDLE;

			//reset boss values
			boss.xPos = ofGetWindowWidth() / 2;
			boss.yPos = ofGetWindowHeight() / 2;
			boss.switchPhase(boss.EASY);

			//delete all bullets
			bulletList.clearList();

			//delete all pickups
			for (int i = 0; i < MAX_PICKUPS; i++)
			{
				if (pickups[i] != NULL)
				{
					delete pickups[i];
					pickups[i] = NULL;
				}
			}

			//reset the final phase timer
			timer.resetTimer();

			////go to main menu
			gameState.switchState(gameState.START);
		}
	}
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}



















































//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
