#include "CurvingBullet.h"

CurvingBullet::CurvingBullet(Player* PlayerToTarget, int startX, int startY)
{
	target = PlayerToTarget;
	xPos = startX;
	yPos = startY;
	damage = 15;
	speed = 4;

	bossXpos = startX;
	bossYpos = startY;

	direction.x = target->xPos - xPos; //////
	direction.y = target->yPos - yPos; //////

	float amplitude = ofRandom(100, 150);
	float changeDirectionChance = ofRandom(0, 100);
	if (changeDirectionChance <= 50)
	{
		amplitude = amplitude * -1;
	}
	curveDepth = amplitude;

	curveDistance = direction.length();
	curveMidpoint = curveDistance / 2;
	direction = direction.getNormalized();


	sprite.load("CurvingBullet.png"); /////// REPLACE WITH ACTUAL IMAGE LATER

}
float CurvingBullet::getAngle() 
{
	//ofVec2f* bossToBullet = new ofVec2f(xPos-bossXpos,yPos-bossYpos);
	ofVec2f bossToBullet;
	bossToBullet.set(xPos - bossXpos, yPos - bossYpos);
	float angle = bossToBullet.angleRad(direction);

	float currentX =  bossToBullet.length() * cos(angle);

	float instantaneousAngle = ((PI * curveDepth) / curveDistance) * cos((PI* currentX)/ curveDistance);

	return instantaneousAngle;
}

void CurvingBullet::move()
{

	ofVec2f rotatedDirection;
	rotatedDirection.set(direction.getRotatedRad(getAngle()));

	xPos += rotatedDirection.x * speed;
	yPos += rotatedDirection.y * speed;

	currDirection = rotatedDirection;

}