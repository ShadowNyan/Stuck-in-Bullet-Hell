#include "HomingBullet.h"

HomingBullet::HomingBullet(Player* PlayerToTarget, int startX, int startY)
{
	target = PlayerToTarget;
	xPos = startX;
	yPos = startY;
	damage = 10;
	speed = 4;

	direction.x = target->xPos - xPos; //////
	direction.y = target->yPos - yPos; //////
	direction = direction.getNormalized();

	sprite.load("HomingBullet.png"); /////// REPLACE WITH ACTUAL IMAGE LATER

}
void HomingBullet::move()
{

	if (lifetime <= maxHomingTime)
	{
		ofVec2f newDirection;
		newDirection.x = target->xPos - xPos;
		newDirection.y = target->yPos - yPos;
		direction = newDirection.getNormalized();

		xPos += direction.x * speed;
		yPos += direction.y * speed;


		lifetime++;
	}
	else
	{
		xPos += direction.x * speed;
		yPos += direction.y * speed;
	}

	currDirection = direction;
}

