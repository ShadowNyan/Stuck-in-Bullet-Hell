#include "UI.h"
ofRectangle* UI::checkIfClicked(float mouseX, float mouseY)
{
	for (int i = 0; i < MAX_BUTTONS; i++)
	{
		if (UIbutton[i]->button.inside(mouseX, mouseY) == true)
		{
			cout << "button clicked" << endl;
			return &UIbutton[i]->button;
		}
		else
		{
			cout << "not today" << endl;
		}
	}
}

void UI::initButtons()
{
	for (int i = 0; i < MAX_BUTTONS; i++)
	{
		if (i == PLAYBUTTON)
		{
			UIbutton[PLAYBUTTON] = new Buttons(ofGetWindowWidth() / 2, ofGetWindowHeight() / 4, 710, 210);

			/////////////
			/*UIbutton[i]->button.setX(ofGetWindowWidth()/2);
			UIbutton[i]->button.setY(ofGetWindowHeight() / 4);
			UIbutton[i]->button.setWidth(100);
			UIbutton[i]->button.setHeight(30);*/
			buttonColor[i] = ofColor::blue;

			////// LOAD SPRITE
			UIbutton[PLAYBUTTON]->sprite.load("playButton.png");

		}
		else if (i == QUITBUTTON)
		{

			UIbutton[QUITBUTTON] = new Buttons(ofGetWindowWidth() / 2, ofGetWindowHeight() / 2, 710, 210);

			/////////////
			/*UIbutton[i]->button.setX(ofGetWindowWidth() / 2);
			UIbutton[i]->button.setY(ofGetWindowHeight() / 2);
			UIbutton[i]->button.setWidth(100);
			UIbutton[i]->button.setHeight(30);*/
			buttonColor[i] = ofColor::green;

			////// LOAD SPRITE
			UIbutton[QUITBUTTON]->sprite.load("quitButton.png");

		}
		else if (i == TITLE)
		{

			UIbutton[TITLE] = new Buttons(0, 0, 710, 210);

			////// LOAD SPRITE
			UIbutton[TITLE]->sprite.load("Title.png");

		}
		else if (i == MAINMENU)
		{

			UIbutton[MAINMENU] = new Buttons(ofGetWindowWidth() / 10, ofGetWindowHeight() / 2, 710, 210);

			////// LOAD SPRITE
			UIbutton[MAINMENU]->sprite.load("MainMenuButton.png");

		}
		/////// ADD BUTTONS HERE
		else
		{
			UIbutton[i]->button.setX(0);
			UIbutton[i]->button.setY(0);
			UIbutton[i]->button.setWidth(100);
			UIbutton[i]->button.setHeight(30);

			buttonColor[i] = ofColor::red;
		}
	}

	/////INIT OTHER UI STUFF

	startBg.load("bg1.png");
	menuBg.load("bg2.png");
	background.load("cracked_stone_floor.png");

}
void UI::drawStartUI()
{
	//////// REPLACE WITH RENDER DRAW FUNCTION (DRAWING BUTTON SPRITE)
	startBg.draw(0, 0);

	ofPushMatrix();
		ofScale(4);
		ofTranslate(10, 30);
		UIbutton[TITLE]->sprite.draw(UIbutton[TITLE]->xPos, UIbutton[TITLE]->yPos); ///////////
	ofPopMatrix();

	ofPushMatrix();
		//ofSetColor(buttonColor[PLAYBUTTON]);
		//ofDrawRectangle(UIbutton[PLAYBUTTON]->button);
		UIbutton[PLAYBUTTON]->sprite.draw(UIbutton[PLAYBUTTON]->xPos, UIbutton[PLAYBUTTON]->yPos); ///////////
	ofPopMatrix();

	ofPushMatrix();
		//ofSetColor(buttonColor[QUITBUTTON]);
		//ofDrawRectangle(UIbutton[QUITBUTTON]->button);
		UIbutton[QUITBUTTON]->sprite.draw(UIbutton[QUITBUTTON]->xPos, UIbutton[QUITBUTTON]->yPos); ///////////
	ofPopMatrix();
}
void UI::drawPauseUI()
{
	menuBg.draw(0, 0);

	ofPushMatrix();
	//ofSetColor(buttonColor[PLAYBUTTON]);
	//ofDrawRectangle(UIbutton[PLAYBUTTON]->button);
	UIbutton[PLAYBUTTON]->sprite.draw(UIbutton[PLAYBUTTON]->xPos, UIbutton[PLAYBUTTON]->yPos); ///////////
	ofPopMatrix();

	ofPushMatrix();
	//ofSetColor(buttonColor[QUITBUTTON]);
	//ofDrawRectangle(UIbutton[QUITBUTTON]->button);
	UIbutton[QUITBUTTON]->sprite.draw(UIbutton[QUITBUTTON]->xPos, UIbutton[QUITBUTTON]->yPos); ///////////
	ofPopMatrix();

	ofPushMatrix();
	//ofSetColor(buttonColor[QUITBUTTON]);
	//ofDrawRectangle(UIbutton[QUITBUTTON]->button);
	UIbutton[MAINMENU]->sprite.draw(UIbutton[MAINMENU]->xPos, UIbutton[MAINMENU]->yPos); ///////////
	ofPopMatrix();
}
void UI::drawGameOverUI()
{
	menuBg.draw(0, 0);

	ofPushMatrix();
	//ofSetColor(buttonColor[QUITBUTTON]);
	//ofDrawRectangle(UIbutton[QUITBUTTON]->button);
	UIbutton[QUITBUTTON]->sprite.draw(UIbutton[QUITBUTTON]->xPos, UIbutton[QUITBUTTON]->yPos); ///////////
	ofPopMatrix();

	ofPushMatrix();
	//ofSetColor(buttonColor[QUITBUTTON]);
	//ofDrawRectangle(UIbutton[QUITBUTTON]->button);
	UIbutton[MAINMENU]->sprite.draw(UIbutton[MAINMENU]->xPos, UIbutton[MAINMENU]->yPos); ///////////
	ofPopMatrix();
}
void UI::drawGameBG()
{
	background.draw(0, 0);
}