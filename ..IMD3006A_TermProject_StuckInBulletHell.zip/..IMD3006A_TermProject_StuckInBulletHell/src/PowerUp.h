#pragma once
#include "GameObject.h"
#include "Player.h"
class PowerUp :
    public GameObject
{
public:
   PowerUp();
   //~PowerUp();

    virtual void onPickup(Player* player) {};
    bool isPickedUp(Player* player, int* numPickups);


};

