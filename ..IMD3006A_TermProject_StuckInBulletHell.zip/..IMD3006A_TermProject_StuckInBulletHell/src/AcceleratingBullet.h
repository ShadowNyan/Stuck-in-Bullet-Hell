#pragma once
#include "Bullet.h"
class AcceleratingBullet :
    public Bullet
{
public:

    ofVec2f direction;

    AcceleratingBullet(Player* PlayerToTarget, int startX, int startY);
    void move();

};

