#pragma once
#include "GameObject.h"
class Timer :
	public GameObject
{
public:

	int timer = 0;
	int startTime = ofGetElapsedTimeMillis();
	bool isTimerActive = false;

	ofTrueTypeFont font;

	Timer();

	void updateTimer();
	void startTimer();
	void resetTimer();
	void drawTimer();


};

