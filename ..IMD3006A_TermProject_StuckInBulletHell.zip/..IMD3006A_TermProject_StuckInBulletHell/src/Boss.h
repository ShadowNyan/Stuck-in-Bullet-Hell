#pragma once
#include "Entity.h"
#include "ofMain.h"
#include <math.h>

//#define MAX_BULLETS 100
class Boss :
    public Entity
{
public:
    enum phases
    {
        EASY = 0,
        NORMAL = 1,
        HARD = 2,
        SURVIVE = 3
    };
    int currentPhase = 0;

    ////enum attackPattern
    ////{
    ////    BEAM = 0,
    ////    CIRCLE = 1,
    ////    SWEEP = 2,
    ////    RANDOM = 3
    ////};
    ////int currentPattern = 0;

    virtual enum state
    {
        ATTACKING = 0,
        MOVING = 1,
        DEAD = 2,
        IDLE = 3,
        KNOCKEBACK = 4
    };
    //int currentState = 1;

    int bossKnockTargetX;
    int bossKnockTargetY;
    bool needSetTarget = true;

    int fireRate = 40; ///// HIGHER NUMBER = SLOWER RATE OF FIRE

    Boss();

    virtual void move();
    virtual void attack();
    virtual void ifDead();

    void nextPhase();
    void switchPhase(int newPhase);
    void changePattern();
    void switchState(int newState);
    bool damagedKnockback(int playerX, int playerY);

};

