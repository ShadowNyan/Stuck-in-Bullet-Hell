#include "Boss.h"
#include "Bullet.h"

Boss::Boss()
{
	speed = 1;
	bossKnockTargetX = 0;
	bossKnockTargetY = 0;

	sprite.load("Boss.png"); /////// REPLACE WITH ACTUAL IMAGE LATER
}

void Boss::move()
{
	static int moveLength = 0;
	if (currentState == MOVING)
	{
		int wallDistanceBuffer = 100;
		if (moveLength < 100)
		{
			int buffer = 60;
			//If the next position is not out of bounds, update position
			if (buffer < xPos + direction.x * speed	&&		xPos + direction.x * speed < ofGetWindowWidth() - buffer
				&& buffer < yPos + direction.y * speed		&&		yPos + direction.y * speed < ofGetWindowHeight()- buffer)
			{
				xPos += direction.x * speed;
				yPos += direction.y * speed;

				//cout << direction.x * speed << " || " << direction.y * speed << endl;
				//cout << xPos << " || " << yPos << endl;
			}

			moveLength++;
		}
		else if (moveLength >= 100 && (wallDistanceBuffer > xPos || ofGetWindowWidth() - wallDistanceBuffer < xPos || wallDistanceBuffer > yPos || ofGetWindowHeight() - wallDistanceBuffer < yPos))
		{
			moveLength = 0;
			switchState(MOVING);
		}
		else
		{
			moveLength = 0;
			currentState = IDLE;
		}
	}

}
void Boss::attack()
{
	////// SPAWN BULLETS DEPENDING ON BULLET TYPE 
}
void Boss::ifDead()
{
	
}
void Boss::switchPhase(int newPhase)
{
	currentPhase = newPhase;
	switch (newPhase)
	{
	case EASY:
		maxHealth = 100;
		fireRate = 40;
		break;
	case NORMAL:
		maxHealth = 200;
		fireRate = 30;
		break;
	case HARD:
		maxHealth = 800;
		fireRate = 20;
		break;
	case SURVIVE:
		maxHealth = 9999999999;
		fireRate = 10;
		break;
	}
	currentHealth = maxHealth;
	currentState = IDLE;
}
void  Boss::nextPhase()
{
	if (currentPhase < 3)
	{
		currentPhase++;
	}

	switchPhase(currentPhase);

	/*switch (currentPhase)
	{
	case EASY:
		maxHealth = 100;
		fireRate = 40;
		break;
	case NORMAL:
		maxHealth = 200;
		fireRate = 30;
		break;
	case HARD:
		maxHealth = 800;
		fireRate = 20;
		break;
	case SURVIVE:
		maxHealth = 9999999999;
		fireRate = 10;
		break;
	}
	currentHealth = maxHealth;
	currentState = IDLE;*/
}
void  Boss::changePattern()
{
	/////// generates a new pattern to use. As the phase/difficulty increases, there are more options to generate from
	//currentPattern = (int) ofRandom(0, currentPhase + 1);

}
void Boss::switchState(int newState)
{
	currentState = newState;

	//setup
	if (currentState == MOVING)
	{
		float destinationX;
		float destinationY;
		int buffer = 150; //60
		//// keep picking a new direction to move in until the destination does not hit a wall
		do
		{
			direction.x = ofRandom(-1, 2);
			direction.y = ofRandom(-1, 2);

			destinationX = xPos + (direction.x * speed * 100);
			destinationY = yPos + (direction.y * speed * 100);

		} while (destinationX < buffer || destinationX > ofGetWindowWidth() - buffer
			|| destinationY < buffer || destinationY > ofGetWindowHeight() - buffer);
		/*direction.x = ofRandom(-1, 2);
		direction.y = ofRandom(-1, 2);*/

		//cout << direction.x << " || " << direction.y << endl;
	}

}
bool  Boss::damagedKnockback(int playerX, int playerY)
{
	ofVec2f knockBackDirection;
	if (needSetTarget == true)
	{
		//set the knockback rest position (get vector between player pos and boss pos)
		knockBackDirection.x = xPos - playerX;
		knockBackDirection.y = yPos - playerY;
		knockBackDirection = knockBackDirection.getNormalized();

		bossKnockTargetX = xPos + knockBackDirection.x * 400;
		bossKnockTargetY = yPos + knockBackDirection.y * 400;

		needSetTarget = false;
	}

	bool finishedKnockback = false;
	int buffer = 70; //70
	//If the next position is not out of bounds, update position
	if (buffer < xPos + direction.x * speed && xPos + direction.x * speed < ofGetWindowWidth() - buffer
		&& buffer < yPos + direction.y * speed && yPos + direction.y * speed < ofGetWindowHeight() - buffer)
	{
		xPos = xPos + (bossKnockTargetX - xPos) * 0.05;
		yPos = yPos + (bossKnockTargetY - yPos) * 0.05;
	}
	else
	{
		//finish knockback if boss hits a wall
		finishedKnockback = true;
	}

	if (abs(xPos - bossKnockTargetX) < 20 && abs(yPos - bossKnockTargetY) < 20)
	{
		finishedKnockback = true;
	}

	return finishedKnockback;
}
