#include "List.h"
#include "math.h"
using namespace std;

List::List()
{
	
}

void List::addBullet(Player* PlayerToTarget, int startX, int startY, int bulletTypeToAdd)
{
	Bullet* newBullet;

	switch (bulletTypeToAdd)
	{
	case NORMAL:
		newBullet = new NormalBullet(PlayerToTarget, startX, startY);
		break;
	case HOMING:
		newBullet = new HomingBullet(PlayerToTarget, startX, startY);
		break;
	case ACCELERATING:
		newBullet = new AcceleratingBullet(PlayerToTarget, startX, startY);
		break;
	case CURVING:
		newBullet = new CurvingBullet(PlayerToTarget, startX, startY);
		break;
	}

	numBullets++;

	//add the first bullet to the list
	if (firstBullet == NULL && lastBullet == NULL)
	{
		firstBullet = newBullet;
		lastBullet = newBullet;

		newBullet->next = NULL;
		newBullet->previous = NULL;

	}
	//add new bullet to the list
	else
	{
		newBullet->next = lastBullet->next;
		lastBullet->next = newBullet;
		newBullet->previous = lastBullet;

		if (newBullet->next == NULL)
		{
			lastBullet = newBullet;
		}
		else
		{
			newBullet->next->previous = newBullet;
		}

	}

	
}

void List::removeBullet(Bullet* bulletToRemove)
{
	numBullets--;
	Bullet* temp;
	temp = bulletToRemove;

	//remove  bullet from the list
	if (bulletToRemove == firstBullet && bulletToRemove == lastBullet)
	{

		firstBullet = NULL;
		lastBullet = NULL;
		delete bulletToRemove;
		bulletToRemove = NULL;
	}
	else
	{
		if (bulletToRemove->previous != NULL)
		{
			bulletToRemove->previous->next = bulletToRemove->next;
		}
		else
		{
			//bulletToRemove->next->previous = bulletToRemove->previous;
			firstBullet = bulletToRemove->next;
		}
		if (bulletToRemove->next != NULL)
		{
			bulletToRemove->next->previous = bulletToRemove->previous;
		}
		else
		{
			//bulletToRemove = bulletToRemove->previous;
			lastBullet = bulletToRemove->previous;
		}
		bulletToRemove->previous = NULL;
		bulletToRemove->next = NULL;

		delete bulletToRemove;
	}
}

void List::clearList()
{
	while (numBullets > 0)
	{
		removeBullet(lastBullet);
	}
}

void List::updateBullets(Player* target)
{
	if (firstBullet != NULL)
	{
		bool keepLooping = true;
		Bullet* currBullet = firstBullet;
		while (keepLooping)
		{
			////// uncomment to visualize linked list in the consol (+ uncomment the cout after the while loop)
			/*if (currBullet == firstBullet || currBullet == lastBullet)
			{
				cout << 1 << " ";
			}
			else
			{
				cout << 0 << " ";
			}*/

			if (currBullet != NULL)
			{
				Bullet* bulletToDelete = NULL;

				bool hasHit = currBullet->hasHit();
				if (hasHit == true)
				{

					bulletToDelete = currBullet;
					
				}
				else
				{
					currBullet->move();

				}

				if (currBullet == lastBullet)
				{
					keepLooping = false;

				}
				else
				{
						currBullet = currBullet->next;
				}

				if (bulletToDelete != NULL)
				{
					removeBullet(bulletToDelete);
				}

			}

		}
		//cout << endl;
	}

}
