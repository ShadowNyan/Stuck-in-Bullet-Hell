#include "Render.h"

void Render::Draw(GameObject* objToDraw)//take a game object and draw on screen
{
	//float drawX = objToDraw->xPos - objToDraw->sprite.getWidth() / 2;
	//float drawY = objToDraw->yPos - objToDraw->sprite.getHeight() / 2;
	//objToDraw->sprite.draw(drawX, drawY);

	objToDraw->sprite.draw(0, 0);
}
void Render::DrawTimer()//takes in timer and draw on screen
{

}
