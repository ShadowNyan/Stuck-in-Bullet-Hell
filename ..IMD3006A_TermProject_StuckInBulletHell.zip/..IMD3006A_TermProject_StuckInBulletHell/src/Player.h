#pragma once
#include "Entity.h"
//#include "ofMain.h"
#include "Boss.h"

class Player :
    public Entity
{
public:
    /*enum state
    {
        IDLE = 0,
        ATTACKING = 1,
        MOVING = 2,
        DEAD = 3

    };
    int currentState;*/
    bool isInvincible;

    ofVec2f direction;
    int inputStoreX[2] = { 0, 0 }; /// A, D
    int inputStoreY[2] = { 0, 0 }; /// W, S

    //attack/dash
    int playerDashTargetX;
    int playerDashTargetY;
    bool needSetTarget = true;
    bool finishedDash = true;

    int playerDmg = 10;
    bool finishedAttack;

    bool onCooldown = false;
    int cooldown = 0;
    int cooldownMax = 150;

    Player();
    
    void move();
    void attack(Entity* target);
    virtual void ifDead();

    bool dash(Boss* target);
    void invisTime();

};

