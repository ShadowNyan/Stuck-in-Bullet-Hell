#include "HealthPickup.h"

HealthPickup::HealthPickup()
{
	///*xPos = ofRandom(50, ofGetWindowWidth() - 50);
	//yPos = ofRandom(50, ofGetWindowHeight() - 50);*/
	
	//xPos = ofGetWindowWidth()/2;
	//yPos = ofGetWindowHeight()/2;

	sprite.load("Pickup.png"); /////// REPLACE WITH ACTUAL IMAGE LATER
}

void HealthPickup::onPickup(Player* player)
{
	////// TEMP PLAYER DAMAGE CHECK
	cout << player->currentHealth << " -> ";/////

	if ((player->currentHealth + healthToRestore) > player->maxHealth)
	{
		player->currentHealth = player->maxHealth;
	}
	else
	{
		player->currentHealth += healthToRestore;
	}

	////// TEMP PLAYER DAMAGE CHECK
	cout << player->currentHealth << endl;/////
}