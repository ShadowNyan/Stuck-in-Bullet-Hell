#pragma once
#include "Bullet.h"
#include "NormalBullet.h"
#include "HomingBullet.h"
#include "AcceleratingBullet.h"
#include "CurvingBullet.h"
#include "ofMain.h"
#include "Player.h"
class List
{
public:

	int numBullets = 0;
	Bullet* firstBullet = NULL;
	Bullet* lastBullet = NULL;

	enum bulletType
	{
		NORMAL = 0,
		HOMING = 1,
		ACCELERATING = 2,
		CURVING = 3
	};

	List();

	void addBullet(Player* PlayerToTarget, int startX, int startY, int bulletTypeToAdd);
	void removeBullet(Bullet* bulletToRemove);
	void clearList();

	void updateBullets(Player* target);

};

