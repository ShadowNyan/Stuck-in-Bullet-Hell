#pragma once

#define MAX_PICKUPS 10
#define MAX_BULLETS 100

#include "ofMain.h"
#include "GameState.h"
#include "UI.h"
#include "Boss.h"
#include "Player.h"
#include "PowerUp.h"
#include "HealthPickup.h"
#include "Bullet.h"
#include "NormalBullet.h"
#include "List.h"
#include "Render.h"
#include "Timer.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);

		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);

		int keys[255];
		bool end = false;

		GameState gameState;
		UI ui;

		//boss
		Boss boss;
		//Bullet* bullets[MAX_BULLETS];
		//int numBullets = 0;
		List bulletList;

		//player
		Player player;

		//pickups
		int numPickups = 0;
		PowerUp* pickups[MAX_PICKUPS];

		//Bullet* testBullet; ///////////////////////////////////////////


		//renderer
		Render render;

		//final phase timer
		Timer timer;


		////////////////
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		
};
