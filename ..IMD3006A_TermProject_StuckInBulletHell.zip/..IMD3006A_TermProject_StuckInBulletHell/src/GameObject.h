#pragma once
#include "ofMain.h"

class GameObject
{
public:

	//int xPos = ofGetWindowWidth()/2;
	//int yPos = ofGetWindowHeight() / 2;
	float xPos = ofGetWindowWidth()/2;
	float yPos = ofGetWindowHeight() / 2;
	ofImage sprite;

	//////////
	// add anim capablility?
	///////////

	void initImg(char* filepath);

};

