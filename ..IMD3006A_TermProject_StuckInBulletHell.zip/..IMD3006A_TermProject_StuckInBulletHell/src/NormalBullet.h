#pragma once
#include "Bullet.h"
class NormalBullet :
    public Bullet
{
public:

    ofVec2f direction;

    NormalBullet(Player* PlayerToTarget, int startX, int startY);
    void move();

};

