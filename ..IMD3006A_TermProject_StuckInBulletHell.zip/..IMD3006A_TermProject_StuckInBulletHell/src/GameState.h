#pragma once
#include "ofMain.h"
class GameState
{
public:

	enum screenType
	{
		START = 0,
		PLAY = 1,
		GAMEOVER = 2,
		PAUSE = 3,
	};
	int currScreen = START;
	ofSoundPlayer music[2];  // 0 = menu, 1 = game

	void switchState(int newState);
	//void initMusic();

};

