#include "Timer.h"

Timer::Timer()
{
	//xPos = ofGetWindowWidth() / 2;
	//yPos = ofGetWindowHeight() / 2;

	font.load("CfKlondikePersonalRegular-KKGW.ttf", 80);
}

void Timer::updateTimer()
{
	if (isTimerActive == true)
	{
		int time = ofGetElapsedTimeMillis() - startTime;
		if (time >= 1000)

		{
			startTime = ofGetElapsedTimeMillis();

			//cout << timer << endl;
			timer++;
		}
	}

}
void Timer::startTimer()
{
	isTimerActive = true;
	timer = 0;

}

void Timer::resetTimer()
{
	isTimerActive = false;
	timer = 0;
}

void Timer::drawTimer()
{
	string timeToDraw = ofToString(timer);

	ofPushMatrix();

	ofSetColor(ofColor::darkGray);
	font.drawString(timeToDraw.c_str(), 100, 100);
	ofSetColor(ofColor::white);

	ofPopMatrix();
}

