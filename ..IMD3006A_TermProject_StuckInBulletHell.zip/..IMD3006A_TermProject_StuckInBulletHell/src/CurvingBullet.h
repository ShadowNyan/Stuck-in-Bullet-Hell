#pragma once
#include "Bullet.h"
class CurvingBullet :
    public Bullet
{
public:

    ofVec2f direction;
    float curveX;
    float bossXpos;
    float bossYpos;
    float curveDistance;
    float curveMidpoint;
    float curveDepth;
    //int maxHomingTime = 100;
    //int lifetime = 0;

    CurvingBullet(Player* PlayerToTarget, int startX, int startY);
    void move();
    float getAngle();

};

