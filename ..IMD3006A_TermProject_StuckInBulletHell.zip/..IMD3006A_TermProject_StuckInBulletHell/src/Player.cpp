#include "Player.h"


Player::Player()
{
	sprite.load("Player.png"); /////// REPLACE WITH ACTUAL IMAGE LATER
}

void Player::move()
{
	//////// CHANGE THE PLAYER'S DIRECTION
	direction.x = inputStoreX[0] + inputStoreX[1];
	direction.y = inputStoreY[0] + inputStoreY[1];



	/////// MOVE THE PLAYER		+ MAKE SURE THE PLAYER DOES NOT MOVE OUT OF BOUNDS
	int buffer = 20;
	//If the next position is not out of bounds, update position
	if (buffer < xPos + direction.x * speed && xPos + direction.x * speed < ofGetWindowWidth() - buffer)
	{
		xPos += direction.x * speed;
	}
	if (buffer < yPos + direction.y * speed && yPos + direction.y * speed < ofGetWindowHeight() - buffer)
	{
		yPos += direction.y * speed;
	}

}

void Player::attack(Entity* target)
{
	int buffer = 30;
	if (abs(xPos - target->xPos) < buffer && abs(yPos - target->yPos) < buffer)
	{
		target->takeDamage(playerDmg);
	}

	if (target->currentHealth <= 0)
	{
		target->currentState = target->DEAD;
	}
}

bool Player::dash(Boss* target)
{
	static ofVec2f dashDirection;
	if (needSetTarget == true)
	{
		///// DASH IN CURRENT PLAYER MOVEMEN DIRECTION
		//direction.x = inputStoreX[0] + inputStoreX[1];
		//direction.y = inputStoreY[0] + inputStoreY[1];

		///// DASH TO MOUSE POSITION
		direction.x = ofGetMouseX() - this->xPos; ////////
		direction.y = ofGetMouseY() - this->yPos; ////////

		dashDirection = direction.getNormalized();
		direction = direction.getNormalized(); //////

		int buffer = 20;

		//cout << dashDirection.x << endl;
		playerDashTargetX = xPos + direction.x * 400;
		playerDashTargetY = yPos + direction.y * 400;

		needSetTarget = false;

		/// "initiate" the attack
		finishedAttack = false;

		///// MAKE PLAYER INVINCIBLE
		isInvincible = true;
	}
	finishedDash = false;
	int buffer = 70;
	int bufferWall = 0;
	// if player has hit the boss
	if (abs(xPos - target->xPos) < buffer && abs(yPos - target->yPos) < buffer)
	{
		//make sure the attack only happens once per dash
		if (finishedAttack == false)
		{
			/// PERFORM THE ATTACK
			target->needSetTarget = true;
			target->currentState = target->KNOCKEBACK;

			//cout << target->currentHealth << " -> ";/////
			target->takeDamage(playerDmg);
			//cout << target->currentHealth << endl;/////
			finishedAttack = true;
		}

		finishedDash = true;
		needSetTarget = true;
		///////// REMOVE INVINCIBILITY
		isInvincible = false;
	}
	//If the next position is not out of bounds, update position
	else if (bufferWall < xPos + direction.x * speed && xPos + direction.x * speed < ofGetWindowWidth() - bufferWall
		&& bufferWall < yPos + direction.y * speed && yPos + direction.y * speed < ofGetWindowHeight() - bufferWall)
	{
		xPos = xPos + (playerDashTargetX - xPos) * 0.1;
		yPos = yPos + (playerDashTargetY - yPos) * 0.1;

		//xPos = xPos + dashDirection.x * 20;
		//yPos = yPos + dashDirection.y * 20;
	}
	else
	{
		//finish dash if player hits a wall
		finishedDash = true;
		needSetTarget = true;
		///////// REMOVE INVINCIBILITY
		isInvincible = false;
	}

	if (abs(xPos - playerDashTargetX) < 20 && abs(yPos - playerDashTargetY) < 20)
	{
		finishedDash = true;
		needSetTarget = true;
		///////// REMOVE INVINCIBILITY
		isInvincible = false;
	}

	return finishedDash;
}
void Player::ifDead()
{

}

void Player::invisTime()
{
	/// if hit, turn isInvincible to true for 3 seconds
}