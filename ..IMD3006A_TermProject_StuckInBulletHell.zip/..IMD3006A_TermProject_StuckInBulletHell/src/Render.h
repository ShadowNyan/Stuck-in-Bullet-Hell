#pragma once
#include "GameObject.h"
class Render
{
public:
	void Draw(GameObject* objToDraw); //take a game object and draw on screen
	void DrawTimer(); //takes in timer and draw on screen

};

