#pragma once
#include "ofMain.h"
#include "GameObject.h"

///wanted to name the class Button but a bug happened where the class is "implemented" 
//but doesn't show up in the files so it won't let me create it with that name
class Buttons :
	public GameObject
{
public:

	ofRectangle button;
	ofColor buttonColor; //// FOR TESTING / DEBUGGING PURPOSES
	
	Buttons();
	Buttons(int x, int y, int width, int height);

};

