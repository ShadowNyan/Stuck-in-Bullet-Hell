#include "Bullet.h"

bool Bullet::hasHit()
{

	int distanceX = abs(target->xPos - xPos);
	int distanceY = abs(target->yPos - yPos);

	int buffer = 15;

	//since health is curr only pickup:  only pick up if health is not maxed
	//isActive makes sure damage is only applied once
	if (isActive == true)
	{//
		if (distanceX < 30 && distanceY < 30)
		{
			if (target->isInvincible == false)
			{
				isActive = false;
				target->takeDamage(damage);

				//delete this;
				return true;
			}
			else
			{
				return false;
			}

		}
		//if touching the edge of the map
		else if ((xPos <= buffer || xPos >= ofGetWindowWidth() - buffer) || (yPos <= buffer || yPos >= ofGetWindowHeight() - buffer))
		{
			//cout << xPos << " " << yPos << " || " << ofGetMouseX() << " " << ofGetMouseY() << endl;
			//*numBullets = *numBullets - 1;
			//delete this;
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		//*numBullets = *numBullets - 1;
		//delete this;
		return true;
	}
}

