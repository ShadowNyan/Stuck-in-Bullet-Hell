#include "Entity.h"

void Entity::move()
{

}
void Entity::attack()
{

}
void Entity::takeDamage(int damageAmnt)
{
	cout << currentHealth << " -> ";/////

	if (currentHealth - damageAmnt >= 0)
	{
		currentHealth -= damageAmnt;
	}
	else
	{
		currentHealth = 0;
	}
	if (currentHealth == 0)
	{
		currentState = DEAD;
	}

	cout << currentHealth << endl;/////
}
void Entity::ifDead()
{

}
