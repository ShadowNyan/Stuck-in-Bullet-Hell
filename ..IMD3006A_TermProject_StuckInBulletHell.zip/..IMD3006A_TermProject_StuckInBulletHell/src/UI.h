#pragma once
#include "ofMain.h"
#include "Buttons.h"
#define MAX_BUTTONS 4
class UI
{
public:

	enum buttonType
	{
		PLAYBUTTON = 0,
		QUITBUTTON = 1,
		TITLE = 2,
		MAINMENU = 3
	};

	//ofRectangle button[MAX_BUTTONS];    /// REPLACE WITH BUTTON CLASS
	ofColor buttonColor[MAX_BUTTONS];
	
	Buttons* UIbutton[MAX_BUTTONS];

	ofImage startBg;
	ofImage menuBg;
	ofImage background;

	ofRectangle* checkIfClicked(float mouseX, float mouseY);
	void initButtons();
	void drawStartUI();
	void drawPauseUI();
	void drawGameOverUI();
	void drawGameBG();
};

