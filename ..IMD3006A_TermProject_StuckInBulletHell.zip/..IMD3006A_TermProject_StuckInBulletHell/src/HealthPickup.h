#pragma once
#include "PowerUp.h"
class HealthPickup :
    public PowerUp
{
public:
    int healthToRestore = 10;

    HealthPickup();
    void onPickup(Player* player);

};

