#include "Buttons.h"

Buttons::Buttons() {}

Buttons::Buttons(int x, int y, int width, int height)
{
	this->xPos = x;
	this->yPos = y;
	button.x = xPos;
	button.y = yPos;
	button.width = width;
	button.height = height;
}