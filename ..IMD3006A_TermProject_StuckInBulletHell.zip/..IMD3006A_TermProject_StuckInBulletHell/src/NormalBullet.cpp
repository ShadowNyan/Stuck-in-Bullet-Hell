#include "NormalBullet.h"

NormalBullet::NormalBullet(Player* PlayerToTarget, int startX, int startY)
{
	target = PlayerToTarget;
	xPos = startX;
	yPos = startY;
	damage = 5;
	speed = 4;

	direction.x = target->xPos - xPos; //////
	direction.y = target->yPos - yPos; //////
	direction = direction.getNormalized();

	sprite.load("NormalBullet.png"); /////// REPLACE WITH ACTUAL IMAGE LATER

}
void NormalBullet::move()
{
	xPos += direction.x * speed;
	yPos += direction.y * speed;

	currDirection = direction;
}
