#include "PowerUp.h"

PowerUp::PowerUp()
{
	xPos = ofRandom(50, ofGetWindowWidth() - 50);
	yPos = ofRandom(50, ofGetWindowHeight() - 50);

	sprite.load("Title.png"); /////// REPLACE WITH ACTUAL IMAGE LATER
}

//PowerUp::~PowerUp()
//{
//
//}

bool PowerUp::isPickedUp(Player* player, int* numPickups)
{
	int distanceX = abs(player->xPos - this->xPos);
	int distanceY = abs(player->yPos - this->yPos);

	//since health is curr only pickup:  only pick up if health is not maxed
	if (distanceX < 30 && distanceY < 30 && player->currentHealth < player->maxHealth)
	{
		onPickup(player);
		*numPickups = *numPickups - 1;
		//delete this;
		return true;
	}
	else
	{
		return false;
	}
}
