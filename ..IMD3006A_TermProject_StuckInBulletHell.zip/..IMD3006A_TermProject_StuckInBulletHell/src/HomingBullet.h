#pragma once
#include "Bullet.h"
class HomingBullet :
    public Bullet
{
public:

    ofVec2f direction;
    int maxHomingTime = 150;
    int lifetime = 0;

    HomingBullet(Player* PlayerToTarget, int startX, int startY);
    void move();

};

