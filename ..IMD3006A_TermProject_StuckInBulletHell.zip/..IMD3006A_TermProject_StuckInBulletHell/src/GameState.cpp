#include "GameState.h"

void GameState::switchState(int newState)
{

	currScreen = newState;

	if (currScreen == 0 || currScreen == 2 || currScreen == 3)
	{
		if (music[0].isLoaded() != true)
		{
			music[0].play();
		}
	}
	else
	{
		if (music[1].isLoaded() != true)
		{
			music[1].play();
		}
	}

}

//void initMusic() {}